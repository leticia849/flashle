import { Container } from "./styles";

const Home = () => {
  return (
    <Container>
      <h1>Home {"<3"}</h1>
    </Container>
  );
};

export default Home;
