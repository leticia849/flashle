import styled from "styled-components";

export const Container = styled.div`
  padding: 3rem;

  h1 {
    font-size: 5rem;
  }
`;
